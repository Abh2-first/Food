
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function Profile() {
  return (
    <div className="bg-black text-green-400 min-h-screen flex flex-col">
      <Navbar />
      <main className="flex flex-col items-center justify-center flex-grow py-20 text-center">
        <h1 className="text-4xl font-bold mb-4">Your Profile</h1>
        <p className="text-green-300 max-w-xl">
          Here you’ll soon see your scan history, personalized analysis trends, and ingredient insights.
        </p>
      </main>
      <Footer />
    </div>
  )
}
