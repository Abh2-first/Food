
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function About() {
  return (
    <div className="bg-black text-green-400 min-h-screen flex flex-col">
      <Navbar />
      <main className="flex flex-col items-center justify-center flex-grow text-center px-4 py-20">
        <h1 className="text-4xl font-bold mb-6">About Ingrective</h1>
        <p className="text-green-300 max-w-2xl">
          Ingrective is built to help users understand food ingredients with the power of AI.
          By scanning the product label, you can instantly know which ingredients are healthy,
          harmful, or neutral based on your health preferences.
        </p>
      </main>
      <Footer />
    </div>
  )
}
