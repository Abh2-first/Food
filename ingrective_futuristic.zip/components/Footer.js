
export default function Footer() {
  return (
    <footer className="bg-gray-900 text-green-500 py-4 text-center mt-10 border-t border-green-700">
      <p>© 2025 Ingrective | All Rights Reserved</p>
    </footer>
  )
}
