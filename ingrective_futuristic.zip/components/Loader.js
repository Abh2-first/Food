
export default function Loader() {
  return (
    <div className="flex flex-col items-center justify-center mt-8">
      <div className="animate-spin rounded-full h-12 w-12 border-b-4 border-green-400"></div>
      <p className="text-green-300 mt-4">Analyzing...</p>
    </div>
  )
}
