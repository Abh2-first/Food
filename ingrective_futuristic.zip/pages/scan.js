
import { useState } from 'react'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import Loader from '../components/Loader'

export default function Scan() {
  const [image, setImage] = useState(null)
  const [result, setResult] = useState('')
  const [loading, setLoading] = useState(false)

  const handleImageChange = (e) => {
    setImage(e.target.files[0])
  }

  const handleAnalyze = async () => {
    if (!image) return
    setLoading(true)
    const formData = new FormData()
    formData.append('file', image)

    try {
      const res = await fetch('https://ingrective-backend-1.onrender.com/analyze', {
        method: 'POST',
        body: formData,
      })
      const data = await res.json()
      setResult(data.result || 'No result found')
    } catch (error) {
      setResult('Error analyzing the image.')
    }
    setLoading(false)
  }

  return (
    <div className="bg-black text-green-400 min-h-screen flex flex-col">
      <Navbar />
      <main className="flex flex-col items-center justify-center flex-grow py-16">
        <h1 className="text-3xl md:text-4xl font-bold mb-8">Scan Your Product</h1>
        <input type="file" accept="image/*" onChange={handleImageChange} className="text-green-300 mb-4" />
        <button
          onClick={handleAnalyze}
          className="bg-green-500 hover:bg-green-400 text-black px-6 py-2 rounded-lg mb-8 font-semibold transition-all duration-300"
        >
          Analyze
        </button>
        {loading ? <Loader /> : result && (
          <div className="bg-gray-900 border border-green-600 rounded-lg p-6 max-w-xl text-green-300 shadow-lg">
            <h2 className="text-2xl font-semibold mb-2">Analysis Result</h2>
            <p>{result}</p>
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
