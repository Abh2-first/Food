
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="bg-black text-green-400 min-h-screen flex flex-col items-center justify-between">
      <Navbar />
      <main className="flex flex-col items-center justify-center text-center px-4 py-20">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 animate-pulse">Welcome to Ingrective</h1>
        <p className="text-lg md:text-xl text-green-300 max-w-2xl mb-8">
          Your personal AI that helps you understand what's inside your food.<br />
          Just scan the label and see how each ingredient matches your health.<br />
          <span className="text-green-500 italic">Read. Analyze. Eat Smart.</span>
        </p>
        <Link href="/scan">
          <button className="bg-green-500 hover:bg-green-400 text-black px-6 py-3 rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-green-400/50">
            Get Started
          </button>
        </Link>
      </main>
      <Footer />
    </div>
  )
}
