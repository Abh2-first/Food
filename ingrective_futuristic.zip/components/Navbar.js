
import Link from 'next/link'

export default function Navbar() {
  return (
    <nav className="flex justify-between items-center px-6 py-4 bg-gray-900 text-green-400 shadow-lg">
      <h1 className="text-2xl font-bold text-green-500">Ingrective</h1>
      <div className="space-x-6">
        <Link href="/">Home</Link>
        <Link href="/scan">Scan</Link>
        <Link href="/profile">Profile</Link>
        <Link href="/about">About</Link>
      </div>
    </nav>
  )
}
